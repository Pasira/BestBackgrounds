package com.example.bestbackgrounds.Database;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.support.annotation.NonNull;

@Entity(tableName = "recientes",primaryKeys = {"urlImg","idCategoria"})
public class Recientes {

    @ColumnInfo(name = "urlImg")
    @NonNull
    private String urlImg;

    @ColumnInfo(name = "idCategoria")
    @NonNull
    private String idCategoria;

    @ColumnInfo(name = "guardarTiempo")
    private String guardarTiempo;

    public Recientes(@NonNull String urlImg, @NonNull String idCategoria, String guardarTiempo) {
        this.urlImg = urlImg;
        this.idCategoria = idCategoria;
        this.guardarTiempo = guardarTiempo;
    }

    @NonNull
    public String getUrlImg() {
        return urlImg;
    }

    public void setUrlImg(@NonNull String urlImg) {
        this.urlImg = urlImg;
    }

    @NonNull
    public String getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(@NonNull String idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getGuardarTiempo() {
        return guardarTiempo;
    }

    public void setGuardarTiempo(String guardarTiempo) {
        this.guardarTiempo = guardarTiempo;
    }
}
