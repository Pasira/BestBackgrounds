package com.example.bestbackgrounds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.bestbackgrounds.Common.Common;
import com.example.bestbackgrounds.Model.AnalyzeModel.ComputerVision;
import com.example.bestbackgrounds.Model.AnalyzeModel.URLUpload;
import com.example.bestbackgrounds.Model.CategoriaItem;
import com.example.bestbackgrounds.Model.FondoItem;
import com.example.bestbackgrounds.Remote.IComputerVision;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SubirFondo extends AppCompatActivity {

    ImageView imgVistaPrevia;
    Button btnBuscar, btnSubir, btnEnviar;
    MaterialSpinner spinner;

    //Material Spinner Data
    Map<String, String> spinnerData = new HashMap<>();

    private Uri filePath; //Ruta del fichero

    String idCategoriaSeleccionada = "", directUrl = "", nameOfFile = "";

    //Firebase Storage
    FirebaseStorage storage;
    StorageReference storageReference;

    IComputerVision mService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subir_fondo);

        mService = Common.getComputerVisionApi();

        //Firebase Storage Init
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        //View
        imgVistaPrevia = (ImageView)findViewById(R.id.imgVistaPrevia);
        btnBuscar = (Button)findViewById(R.id.btnBuscar);
        btnSubir = (Button)findViewById(R.id.btnSubir);
        btnEnviar = (Button)findViewById(R.id.btnEnviar); 
        spinner = (MaterialSpinner)findViewById(R.id.spinner);

        //Load Spinner Data
        cargarCategoriaASpinner();

        //Button Event
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                elegirImg();
            }
        });

        btnSubir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedIndex() == 0) //Ocultar si no a seleccionado ninguna categoria
                    Toast.makeText(SubirFondo.this, "Porfavor, seleccione una categoría", Toast.LENGTH_SHORT).show();
                else
                    subir();
            }
        });
        
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detectarContenidoAdulto(directUrl);
            }
        });

    }

    private void detectarContenidoAdulto(final String directUrl) {
        if(directUrl.isEmpty())
            Toast.makeText(this, "Imagen no subida", Toast.LENGTH_SHORT).show();
        else {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Analizando Imagen...");
            progressDialog.show();

            mService.analyzeImage(Common.getAPIAdultEndPoint(), new URLUpload(directUrl))
                    .enqueue(new Callback<ComputerVision>() {
                        @Override
                        public void onResponse(Call<ComputerVision> call, Response<ComputerVision> response) {
                            if(response.isSuccessful()){
                                if(!response.body().getAdult().isAdultContent()){
                                    //Si la imagen no contiene contenido adulto, la guardaremos en la galeria
                                    progressDialog.dismiss();
                                    guardarUrlCategoria(idCategoriaSeleccionada, directUrl);
                                    Toast.makeText(SubirFondo.this, "Se ha subido correctamente", Toast.LENGTH_SHORT).show();
                                }else {
                                    //Si tuviese contenido adulto, lo borraremos directamente de nuestro Firebase Storage
                                    eliminarArchivoAdulto(nameOfFile);
                                }

                            }
                        }

                        @Override
                        public void onFailure(Call<ComputerVision> call, Throwable t) {
                            Toast.makeText(SubirFondo.this, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void eliminarArchivoAdulto(String nameOfFile) {
        storageReference.child("images/"+nameOfFile)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(SubirFondo.this, "Tu imagen tiene contenido adulto y será eliminado", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void subir() {
        if(filePath != null){
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Cargando...");
            progressDialog.show();

            nameOfFile = UUID.randomUUID().toString();
            StorageReference ref = storageReference.child(new StringBuilder("images/").append(nameOfFile)
            .toString());

            ref.putFile(filePath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    progressDialog.dismiss();

                    taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            directUrl = uri.toString();
                            btnEnviar.setEnabled(true);

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(SubirFondo.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    progressDialog.dismiss();
                    Toast.makeText(SubirFondo.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                    progressDialog.setMessage("Subido: " + (int)progress + "%");
                }
            });
        }
    }

    private void guardarUrlCategoria(String idCategoriaSeleccionada, String urlImg) {
        FirebaseDatabase.getInstance()
                .getReference(Common.STR_FONDO)
                .push() //Generar la key
                .setValue(new FondoItem(urlImg, idCategoriaSeleccionada))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(SubirFondo.this, "¡Subida Correctamente!", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == Common.PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
            filePath = data.getData();
            try{
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imgVistaPrevia.setImageBitmap(bitmap);
                btnSubir.setEnabled(true);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void elegirImg() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Seleccione una Imagen: "), Common.PICK_IMAGE_REQUEST);
    }

    private void cargarCategoriaASpinner() {
        FirebaseDatabase.getInstance()
                .getReference(Common.STR_FONDO_CATEGORIA)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot postSnapShot:dataSnapshot.getChildren()){
                            CategoriaItem item = postSnapShot.getValue(CategoriaItem.class);
                            String key = postSnapShot.getKey();

                            spinnerData.put(key, item.getNombre());
                        }

                        //Spinner personalizado
                        Object[] valueArray = spinnerData.values().toArray();
                        List<Object> valueList = new ArrayList<>();
                        valueList.add(0, "Categoría"); //Añadir el primer item a la lista
                        valueList.addAll(Arrays.asList(valueArray)); //Añadir el nombre de las categorias restantes
                        spinner.setItems(valueList); //Establecer los datos al spinner
                        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                                //Cuando el usuario escoga una categoria, cogeremos la idCategoria (key)
                                Object[] keyArray = spinnerData.keySet().toArray();
                                List<Object> keyList = new ArrayList<>();
                                keyList.add(0, "CategoríaKey");
                                keyList.addAll(Arrays.asList(keyArray));
                                idCategoriaSeleccionada = keyList.get(position).toString(); //Asignar la key cuando el usuario escoga la categoria
                            }
                        });

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    //Cambiar el metodo cuando el usuario le de atras, par que no guarde los datos en la base de datos
    //si no le da al btn enviar
    @Override
    public void onBackPressed() {
        eliminarArchivoAdulto(nameOfFile);
        super.onBackPressed();
    }
}
