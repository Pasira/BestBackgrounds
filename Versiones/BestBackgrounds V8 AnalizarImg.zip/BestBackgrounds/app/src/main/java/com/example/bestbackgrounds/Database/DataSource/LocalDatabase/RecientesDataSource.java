package com.example.bestbackgrounds.Database.DataSource.LocalDatabase;

import com.example.bestbackgrounds.Database.DataSource.IRecientesDataSource;
import com.example.bestbackgrounds.Database.Recientes;

import java.util.List;

import io.reactivex.Flowable;

public class RecientesDataSource implements IRecientesDataSource {

    private RecientesDAO recientesDAO;
    private static RecientesDataSource instance;

    public RecientesDataSource(RecientesDAO recientesDAO) {
        this.recientesDAO = recientesDAO;
    }

    public static RecientesDataSource getInstance(RecientesDAO recientesDAO){
        if(instance == null)
            instance = new RecientesDataSource(recientesDAO);
        return instance;
    }

    @Override
    public Flowable<List<Recientes>> traerTodosRecientes() {
        return recientesDAO.traerTodosRecientes();
    }

    @Override
    public void insertarRecientes(Recientes... recientes) {
        recientesDAO.insertarRecientes(recientes);
    }

    @Override
    public void actualizarReciente(Recientes... recientes) {
        recientesDAO.actualizarReciente(recientes);
    }

    @Override
    public void eliminarRecientes(Recientes... recientes) {
        recientesDAO.eliminarRecientes(recientes);
    }

    @Override
    public void eliminarTodosRecientes() {
        recientesDAO.eliminarTodosRecientes();
    }
}
