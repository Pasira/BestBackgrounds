package com.example.bestbackgrounds.Common;

import com.example.bestbackgrounds.Model.FondoItem;
import com.example.bestbackgrounds.Remote.IComputerVision;
import com.example.bestbackgrounds.Remote.RetrofitClient;

public class Common {

    public static final String STR_FONDO_CATEGORIA = "FondoCategoria";
    public static final String STR_FONDO = "Fondos";
    public static final int SIGN_IN_REQUEST_CODE = 1001;
    public static final int PICK_IMAGE_REQUEST = 1002;
    public static String CATEGORIA_SELECCIONADA;
    public static String ID_CATEGORIA_SELECCIONADA;

    public static final int PERMISSION_REQUEST_CODE = 1000;

    public static FondoItem seleccionar_fondo = new FondoItem();

    public static String seleccionar_fondo_key;

    //API Computer Vision
    public static String BASE_URL = "https://westcentralus.api.cognitive.microsoft.com/vision/v1.0/";
    public static IComputerVision getComputerVisionApi(){
        return RetrofitClient.getClient(BASE_URL).create(IComputerVision.class);
    }

    public static String getAPIAdultEndPoint(){
        return new StringBuilder(BASE_URL).append("analyze?visualFeatures=Adult&language=es").toString();
    }

}
