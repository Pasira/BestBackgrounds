package com.example.bestbackgrounds.Model;

public class FondoItem {
    public String urlImagen;
    public String idCategoria;
    public  long numVisto;

    public FondoItem(){

    }

    public FondoItem(String urlImagen, String idCategoria) {
        this.urlImagen = urlImagen;
        this.idCategoria = idCategoria;
    }

    public String getUrlImagen() {
        return urlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }

    public String getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(String idCategoria) {
        this.idCategoria = idCategoria;
    }

    public long getNumVisto() {
        return numVisto;
    }

    public void setNumVisto(long numVisto) {
        this.numVisto = numVisto;
    }
}
