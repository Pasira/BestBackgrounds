package com.example.bestbackgrounds.Fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bestbackgrounds.Common.Common;
import com.example.bestbackgrounds.Interface.ItemClickListener;
import com.example.bestbackgrounds.ListaFondos;
import com.example.bestbackgrounds.Model.FondoItem;
import com.example.bestbackgrounds.MostrarFondos;
import com.example.bestbackgrounds.R;
import com.example.bestbackgrounds.ViewHolder.ListaFondosViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

/**
 * A simple {@link Fragment} subclass.
 */

public class PopularFragment extends Fragment {

    RecyclerView recyclerView;

    FirebaseDatabase database;
    DatabaseReference fondoCategoria;

    FirebaseRecyclerOptions<FondoItem> options;
    FirebaseRecyclerAdapter<FondoItem,ListaFondosViewHolder> adapter;

    private static PopularFragment INSTANCE = null;

    public PopularFragment() {
        //Init Firebase
        database = FirebaseDatabase.getInstance();
        fondoCategoria = database.getReference(Common.STR_FONDO);

        Query query = fondoCategoria.orderByChild("numVisto")
                .limitToLast(10); //Coger los 10 items con mayor visualizacion

        options = new FirebaseRecyclerOptions.Builder<FondoItem>()
                .setQuery(query,FondoItem.class)
                .build();

        adapter = new FirebaseRecyclerAdapter<FondoItem, ListaFondosViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final ListaFondosViewHolder holder, int position, @NonNull final FondoItem model) {
                Picasso.get()
                        .load(model.getUrlImagen())
                        .into(holder.fondo, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError(Exception ex) {
                                Picasso.get()
                                        .load(model.getUrlImagen())
                                        .error(R.drawable.ic_error_black_24dp)
                                        .networkPolicy(NetworkPolicy.OFFLINE)
                                        .into(holder.fondo, new Callback() {
                                            @Override
                                            public void onSuccess() {

                                            }

                                            @Override
                                            public void onError(Exception ex) {
                                                Log.e ("ERROR", "No se pudo obtener la imagen");
                                            }
                                        });
                            }
                        });

                holder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        Intent intent = new Intent(getActivity(), MostrarFondos.class);
                        Common.seleccionar_fondo = model;
                        Common.seleccionar_fondo_key = adapter.getRef(position).getKey();
                        startActivity(intent);

                    }
                });
            }

            @NonNull
            @Override
            public ListaFondosViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View itemView = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.layout_fondo_item, viewGroup, false);
                int height = viewGroup.getMeasuredHeight()/2;
                itemView.setMinimumHeight(height);
                return new ListaFondosViewHolder(itemView);
            }
        };
    }

    public static PopularFragment getInstance(){
        if (INSTANCE == null)
            INSTANCE = new PopularFragment();
        return INSTANCE;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_popular, container, false);
        recyclerView = (RecyclerView)view.findViewById(R.id.popularRecycler);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        //Invertimos el RecyclerView para que muestre los mas largos primero, ya que Firebase muestra los cortos primero por defecto
        linearLayoutManager.setStackFromEnd(true);
        linearLayoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        cargarListaPopulares();

        return view;
    }

    private void cargarListaPopulares() {
        adapter.startListening();
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onStop() {
        if(adapter != null)
            adapter.stopListening();
        super.onStop();
    }

    @Override
    public void onStart() {
        super.onStart();
        if(adapter != null)
            adapter.startListening();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(adapter != null)
            adapter.startListening();
    }
}
