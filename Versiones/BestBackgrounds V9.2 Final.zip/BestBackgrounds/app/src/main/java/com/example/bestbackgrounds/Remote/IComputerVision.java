package com.example.bestbackgrounds.Remote;

import com.example.bestbackgrounds.Model.AnalyzeModel.ComputerVision;
import com.example.bestbackgrounds.Model.AnalyzeModel.URLUpload;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface IComputerVision {
    @Headers({
            "Content-Type:application/json",
            "Ocp-Apim-Subscription-Key:ca5eead3fcfd4bbbb963a89693386ff5"
    })
    @POST
    Call<ComputerVision> analyzeImage(@Url String apiEndPoint, @Body URLUpload url);
}
