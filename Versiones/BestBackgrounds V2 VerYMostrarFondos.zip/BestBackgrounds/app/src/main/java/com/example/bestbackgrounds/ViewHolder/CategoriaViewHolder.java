package com.example.bestbackgrounds.ViewHolder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bestbackgrounds.Interface.ItemClickListener;
import com.example.bestbackgrounds.R;

public class CategoriaViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView nombreCategoria;
    public ImageView fondoImg;

    ItemClickListener itemClickListener;

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public CategoriaViewHolder(@NonNull View itemView) {
        super(itemView);
        fondoImg = (ImageView)itemView.findViewById(R.id.imagen);
        nombreCategoria = (TextView)itemView.findViewById(R.id.nombre);

        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        itemClickListener.onClick(v, getAdapterPosition());
    }
}
