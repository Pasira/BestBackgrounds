package com.example.bestbackgrounds.ViewHolder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.example.bestbackgrounds.Interface.ItemClickListener;
import com.example.bestbackgrounds.R;

public class ListaFondosViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    ItemClickListener itemClickListener;

    public ImageView fondo;

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public ListaFondosViewHolder(@NonNull View itemView) {
        super(itemView);
        fondo = (ImageView) itemView.findViewById(R.id.imagen);
        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        itemClickListener.onClick(v, getAdapterPosition());
    }
}
