package com.example.bestbackgrounds.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bestbackgrounds.Common.Common;
import com.example.bestbackgrounds.Database.Recientes;
import com.example.bestbackgrounds.Interface.ItemClickListener;
import com.example.bestbackgrounds.ListaFondos;
import com.example.bestbackgrounds.Model.FondoItem;
import com.example.bestbackgrounds.MostrarFondos;
import com.example.bestbackgrounds.R;
import com.example.bestbackgrounds.ViewHolder.ListaFondosViewHolder;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MyRecyclerAdapater extends RecyclerView.Adapter<ListaFondosViewHolder> {

    private Context context;
    private List<Recientes> recientes;

    public MyRecyclerAdapater(Context context, List<Recientes> recientes) {
        this.context = context;
        this.recientes = recientes;
    }

    @NonNull
    @Override
    public ListaFondosViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_fondo_item, viewGroup, false);

        int height = viewGroup.getMeasuredHeight()/2;
        itemView.setMinimumHeight(height);
        return new ListaFondosViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListaFondosViewHolder listaFondosViewHolder, final int i) {
        Picasso.get()
                .load(recientes.get(i).getUrlImg())
                .networkPolicy(NetworkPolicy.OFFLINE)
                .into(listaFondosViewHolder.fondo, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError(Exception ex) {
                        Picasso.get()
                                .load(recientes.get(i).getUrlImg())
                                .error(R.drawable.ic_error_black_24dp)
                                .networkPolicy(NetworkPolicy.OFFLINE)
                                .into(listaFondosViewHolder.fondo, new Callback() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onError(Exception ex) {
                                        Log.e ("ERROR", "No se pudo obtener la imagen");
                                    }
                                });
                    }
                });

        listaFondosViewHolder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onClick(View view, int position) {
                Intent intent = new Intent(context, MostrarFondos.class);
                FondoItem fondoItem = new FondoItem();
                fondoItem.setIdCategoria(recientes.get(position).getIdCategoria());
                fondoItem.setUrlImagen(recientes.get(position).getUrlImg());
                Common.seleccionar_fondo = fondoItem;
                Common.seleccionar_fondo_key = recientes.get(position).getKey();
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return recientes.size();
    }
}
