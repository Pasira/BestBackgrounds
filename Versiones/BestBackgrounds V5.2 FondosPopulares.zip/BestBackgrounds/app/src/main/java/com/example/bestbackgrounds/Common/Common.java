package com.example.bestbackgrounds.Common;

import com.example.bestbackgrounds.Model.FondoItem;

public class Common {

    public static final String STR_FONDO_CATEGORIA = "FondoCategoria";
    public static final String STR_FONDO = "Fondos";
    public static String CATEGORIA_SELECCIONADA;
    public static String ID_CATEGORIA_SELECCIONADA;

    public static final int PERMISSION_REQUEST_CODE = 1000;

    public static FondoItem seleccionar_fondo = new FondoItem();

    public static String seleccionar_fondo_key;

}
