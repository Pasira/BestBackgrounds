package com.example.bestbackgrounds.Model;

//Creación del modelo para la categoria
public class CategoriaItem {

    public String nombre;
    public String urlImg;

    public CategoriaItem(){

    }

    public CategoriaItem(String nombre, String urlImg) {
        this.nombre = nombre;
        this.urlImg = urlImg;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUrlImg() {
        return urlImg;
    }

    public void setUrlImg(String urlImg) {
        this.urlImg = urlImg;
    }
}
