package com.example.bestbackgrounds.Adapter;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.bestbackgrounds.Fragment.CategoriaFragment;
import com.example.bestbackgrounds.Fragment.PopularFragment;
import com.example.bestbackgrounds.Fragment.RecientesFragment;

public class MyFragmentAdapter extends FragmentPagerAdapter {

    private Context context;

    public MyFragmentAdapter(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;
    }

    //ViewPager adapter para TabLayouts
    @Override
    public Fragment getItem(int i) {
        if(i == 0)
            return CategoriaFragment.getInstance();
        else if (i == 1)
            return PopularFragment.getInstance();
        else if (i == 2)
            return RecientesFragment.getInstance();
        else
            return null;

    }

    //A devolver los *3* Fragments
    @Override
    public int getCount() {
        return 3;
    }

    //Títulos TabLayouts
    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position){
            case 0:
                return "Categorias";

            case 1:
                return "Populares";

            case 2:
                return "Recientes";
        }

        return "";

    }
}
