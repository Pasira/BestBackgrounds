package com.example.bestbackgrounds.Common;

public class Common {

    public static final String STR_FONDO_CATEGORIA = "FondoCategoria";
}
