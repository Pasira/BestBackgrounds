package com.example.bestbackgrounds.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bestbackgrounds.Common.Common;
import com.example.bestbackgrounds.Interface.ItemClickListener;
import com.example.bestbackgrounds.Model.CategoriaItem;
import com.example.bestbackgrounds.R;
import com.example.bestbackgrounds.ViewHolder.CategoriaViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

public class CategoriaFragment extends Fragment {

    //Firebase
    FirebaseDatabase db;
    DatabaseReference fondoCategoria;

    //FirebaseUI Adapter
    FirebaseRecyclerOptions<CategoriaItem> opciones;
    FirebaseRecyclerAdapter<CategoriaItem, CategoriaViewHolder> adapter;

    //View
    RecyclerView  recyclerView;

    private static CategoriaFragment INSTANCE = null;

    public CategoriaFragment() {
        db = FirebaseDatabase.getInstance();
        fondoCategoria = db.getReference(Common.STR_FONDO_CATEGORIA);

        opciones = new FirebaseRecyclerOptions.Builder<CategoriaItem>()
                .setQuery(fondoCategoria, CategoriaItem.class) //SeleccionarTodo
                .build();

        adapter = new FirebaseRecyclerAdapter<CategoriaItem, CategoriaViewHolder>(opciones) {
            @Override
            protected void onBindViewHolder(@NonNull final CategoriaViewHolder holder, int position, @NonNull final CategoriaItem model) {
                Picasso.with(getActivity())
                        .load(model.getUrlImg())
                        .networkPolicy(NetworkPolicy.OFFLINE)
                        .into(holder.fondoImg, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {
                                //Prueba de nuevo online si la cache falla
                                Picasso.with(getActivity())
                                        .load(model.getUrlImg())
                                        .error(R.drawable.ic_error_black_24dp)
                                        .into(holder.fondoImg, new Callback() {
                                            @Override
                                            public void onSuccess() {

                                            }

                                            @Override
                                            public void onError() {
                                                Log.e("ERROR", "No se ha podido recuperar la imagen");
                                            }
                                        });
                            } //En caso de Fallo
                        });

                holder.nombreCategoria.setText(model.getNombre());

                holder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        //Codigo tarde para la categoria de detalle
                    }
                });

            }

            @NonNull
            @Override
            public CategoriaViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View itemView = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.categoria_layout, viewGroup, false);
                return new CategoriaViewHolder(itemView);
            }
        };
    }

    public static CategoriaFragment getInstance(){
        if (INSTANCE == null)
            INSTANCE = new CategoriaFragment();
        return INSTANCE;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_categoria, container, false);
        recyclerView = (RecyclerView)view.findViewById(R.id.categoriaRecycler);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setLayoutManager(gridLayoutManager);

        setCategoria();

        return view;
    }

    private void setCategoria(){
        adapter.startListening();
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        if(adapter != null)
            adapter.startListening();
    }

    @Override
    public void onStop() {
        if(adapter != null)
            adapter.stopListening();
        super.onStop();

    }

    @Override
    public void onResume() {
        super.onResume();
        if(adapter != null)
            adapter.startListening();
    }
}
