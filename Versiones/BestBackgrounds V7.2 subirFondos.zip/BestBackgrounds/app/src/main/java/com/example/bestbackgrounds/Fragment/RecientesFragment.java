package com.example.bestbackgrounds.Fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bestbackgrounds.Adapter.MyRecyclerAdapter;
import com.example.bestbackgrounds.Database.DataSource.RepositorioReciente;
import com.example.bestbackgrounds.Database.LocalDatabase.LocalDatabase;
import com.example.bestbackgrounds.Database.LocalDatabase.RecientesDataSource;
import com.example.bestbackgrounds.Database.Recientes;
import com.example.bestbackgrounds.R;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 */


@SuppressLint("ValidFragment")
public class RecientesFragment extends Fragment {

    private static RecientesFragment INSTANCE = null;

    RecyclerView recyclerView;

    Context context;

    List<Recientes> recientesList;
    MyRecyclerAdapter adapter;

    //Room Database
    CompositeDisposable compositeDisposable;
    RepositorioReciente repositorioReciente;


    public RecientesFragment(Context context) {
        // Required empty public constructor
        this.context = context;

        //Init RoomDatabase
        compositeDisposable = new CompositeDisposable();
        LocalDatabase db = LocalDatabase.getInstance(context);
        repositorioReciente = RepositorioReciente.getInstance(RecientesDataSource.getInstance(db.recientesDAO()));
    }

    public static RecientesFragment getInstance(Context context){
        if (INSTANCE == null)
            INSTANCE = new RecientesFragment(context);
        return INSTANCE;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_recientes, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recienteRecycler);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recientesList = new ArrayList<>();
        adapter = new MyRecyclerAdapter(context, recientesList);
        recyclerView.setAdapter(adapter);

        cargarRecientes();

        return view;
    }

    private void cargarRecientes() {
        Disposable disposable = repositorioReciente.getAllRecientes()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Consumer<List<Recientes>>() {
                    @Override
                    public void accept(List<Recientes> recientes) throws Exception {
                        exitoTraerRecientes(recientes);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.d("ERROR", throwable.getMessage());
                    }
                });

        compositeDisposable.add(disposable);

    }

    private void exitoTraerRecientes(List<Recientes> recientes) {
        recientesList.clear();
        recientesList.addAll(recientes);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onDestroy() {
        compositeDisposable.clear();
        super.onDestroy();
    }
}
