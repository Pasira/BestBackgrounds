package com.example.bestbackgrounds.Remote;

import retrofit2.http.Body;
import retrofit2.Call;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface IComputerVision {
    @Headers({
            "Content-type:application/json", //HeaderName, HeaderValue
            "Ocp-Apim-Subscription-Key: xxxxxxxxxxxx" //HeaderName, Key1
    })
    @POST
    Call<Compute>
}
