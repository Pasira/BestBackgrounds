package com.example.bestbackgrounds.Database.LocalDatabase;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.example.bestbackgrounds.Database.Recientes;

import java.util.List;

import io.reactivex.Flowable;

@Dao
public interface RecientesDAO {
    @Query("SELECT * FROM recientes ORDER BY guardarTiempo DESC LIMIT 10")
    Flowable<List<Recientes>> getAllRecientes();

    @Insert
    void insertarRecientes(Recientes... recientes);

    @Update
    void actualizarRecientes(Recientes... recientes);

    @Delete
    void eliminarRecientes(Recientes... recientes);

    @Query("DELETE FROM recientes")
    void eliminarTodosRecientes();
}
