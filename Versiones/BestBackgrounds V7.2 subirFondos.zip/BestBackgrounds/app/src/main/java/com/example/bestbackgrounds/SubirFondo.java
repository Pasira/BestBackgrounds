package com.example.bestbackgrounds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.bestbackgrounds.Common.Common;
import com.example.bestbackgrounds.Model.CategoriaItem;
import com.example.bestbackgrounds.Model.FondoItem;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.Format;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SubirFondo extends AppCompatActivity {

    ImageView vistaPreviaImg;
    Button btnBuscar, btnSubir;
    MaterialSpinner spinner;

    //Material Spinner Data
    Map<String, String> spinnerData = new HashMap<>();

    private Uri filePath;

    String idCategoriaSeleccionada = "";

    //FirebaseStorage
    FirebaseStorage almacenamiento;
    StorageReference refAlamacenamiento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subir_fondo);

        //Firebase Storage Init
        almacenamiento = FirebaseStorage.getInstance();
        refAlamacenamiento = almacenamiento.getReference();

        //View
        vistaPreviaImg = (ImageView)findViewById(R.id.vistaPreviaImg);
        btnBuscar = (Button)findViewById(R.id.btnBuscar);
        btnSubir = (Button)findViewById(R.id.btnSubir);
        spinner = (MaterialSpinner)findViewById(R.id.spinner);

        //Load Spinner data
        cargarCategoriaASpinner();

        //Button Event
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                elegirImg();
            }

        });

        btnSubir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedIndex() == 0) //Pendiente
                    Toast.makeText(SubirFondo.this, "Porfavor, seleccione una categoría", Toast.LENGTH_SHORT).show();
                else
                    subir();
            }

        });

    }

    private void subir() {
        if(filePath != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Cargando...");
            progressDialog.show();

            final StorageReference ref = refAlamacenamiento.child(new StringBuilder("images/").append(UUID.randomUUID().toString())
            .toString());

            ref.putFile(filePath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    progressDialog.dismiss();


                    /*UploadTask uploadTask = ref.putFile(filePath);
                    uploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            progressDialog.setMessage("Subido : " + (int) progress + "%");
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(SubirFondo.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                        @Override
                        public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                            if (!task.isSuccessful()) {
                                throw task.getException();
                            } // Continue with the task to get the download URL
                            return ref.getDownloadUrl();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if (task.isSuccessful()) {
                                Uri downloadUri = task.getResult();
                                progressDialog.dismiss();
                               // guardarUrlCategoria(idCategoriaSeleccionada, downloadUri.toString()); // comment because next part
                                //directUrl = downloadUri.toString();
                                btnSubir.setEnabled(true);
                            } else {
                                // Handle failures
                                // ...
                                Toast.makeText(SubirFondo.this, "get download link failures", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });*/

                    UploadTask uploadTask = ref.putFile(filePath);
                    uploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            btnSubir.setEnabled(true);
                        }
                    });
                    guardarUrlCategoria(idCategoriaSeleccionada, taskSnapshot.getStorage().getDownloadUrl().toString());
                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(SubirFondo.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            progressDialog.setMessage("Subida : " + (int)progress + "%");
                        }
                    });
                }

            //});
        //}

    }

    private void guardarUrlCategoria(String idCategoriaSeleccionada, String urlImagen) {
        FirebaseDatabase.getInstance()
                .getReference(Common.STR_FONDO).push() //Generar la key
                .setValue(new FondoItem(urlImagen, idCategoriaSeleccionada))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(SubirFondo.this, "Se ha subido correctamente", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == Common.SOLICITAR_IMAGEN && resultCode == RESULT_OK && data != null && data.getData() != null){
            filePath = data.getData();
            try{
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                vistaPreviaImg.setImageBitmap(bitmap);
                btnSubir.setEnabled(true);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void elegirImg() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Seleccionar Imagen: "), Common.SOLICITAR_IMAGEN);
    }

    private void cargarCategoriaASpinner() {
        FirebaseDatabase.getInstance()
                .getReference(Common.STR_FONDO_CATEGORIA)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot postSnapshot:dataSnapshot.getChildren()) {
                            CategoriaItem item = postSnapshot.getValue(CategoriaItem.class);
                            String key = postSnapshot.getKey();

                            spinnerData.put(key, item.getNombre());
                        }

                        //Spinner personalizado
                        Object[] valueArray = spinnerData.values().toArray();
                        List<Object> valueList = new ArrayList<>();
                        valueList.add(0, "Categoria"); //Añadir el primer item a la lista
                        valueList.addAll(Arrays.asList(valueArray)); //Añadir el nombre de las categorias restantes
                        spinner.setItems(valueList); //Establecer los datos al spinner
                        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                                //Cuando el usuario escoga una categoria, cogeremos la idCategoria (key)
                                Object[] keyArray = spinnerData.keySet().toArray();
                                List<Object> keyList = new ArrayList<>();
                                keyList.add(0, "KeyCategoria");
                                keyList.addAll(Arrays.asList(keyArray));
                                idCategoriaSeleccionada = keyList.get(position).toString(); //Asignar la key cuando el usuario escoga la categoria
                            }
                        });

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }
}
