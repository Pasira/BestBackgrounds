package com.example.bestbackgrounds;

import android.Manifest;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.bestbackgrounds.Common.Common;
import com.example.bestbackgrounds.Database.DataSource.RepositorioReciente;
import com.example.bestbackgrounds.Database.LocalDatabase.LocalDatabase;
import com.example.bestbackgrounds.Database.LocalDatabase.RecientesDataSource;
import com.example.bestbackgrounds.Database.Recientes;
import com.example.bestbackgrounds.Helper.SaveImageHelper;
import com.example.bestbackgrounds.Model.FondoItem;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import dmax.dialog.SpotsDialog;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class MostrarFondos extends AppCompatActivity {

    CollapsingToolbarLayout collapsingToolbarLayout;
    FloatingActionButton floatingActionButton, descargaFab;
    ImageView imageView;
    CoordinatorLayout rootLayout;

    //Room Datbase
    CompositeDisposable compositeDisposable;
    RepositorioReciente repositorioReciente;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case Common.PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    AlertDialog dialog = new SpotsDialog(MostrarFondos.this);
                    dialog.show();
                    dialog.setMessage("Porfavor espere...");

                    String fileName = UUID.randomUUID().toString()+".png";
                    Picasso.get().load(Common.seleccionar_fondo.getUrlImagen()).into(new SaveImageHelper(getBaseContext(),dialog,getApplicationContext().getContentResolver(),fileName,"BestBackgrounds Imagen"));

                }
                else{
                    Toast.makeText(this, "Necesitas aceptar los permisos para descargar la imagen", Toast.LENGTH_SHORT).show();
                }
            }
            break;
        }
    }

    private Target target = new Target() {
        @Override
        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
            try {
                wallpaperManager.setBitmap(bitmap);
                Snackbar.make(rootLayout, "Se ha establecido el fondo de pantalla", Snackbar.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onBitmapFailed(Exception e, Drawable errorDrawable) {

        }

        @Override
        public void onPrepareLoad(Drawable placeHolderDrawable) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_fondos);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Init RoomDatabase
        compositeDisposable = new CompositeDisposable();
        LocalDatabase db = LocalDatabase.getInstance(this);
        repositorioReciente = RepositorioReciente.getInstance(RecientesDataSource.getInstance(db.recientesDAO()));

        //Init
        rootLayout = (CoordinatorLayout)findViewById(R.id.rootLayout);
        collapsingToolbarLayout = (CollapsingToolbarLayout)findViewById(R.id.collapsing);
        collapsingToolbarLayout.setCollapsedTitleTextAppearance(R.style.CollapsedAppBar);
        collapsingToolbarLayout.setExpandedTitleTextAppearance(R.style.ExpadedAppBar);

        collapsingToolbarLayout.setTitle(Common.CATEGORIA_SELECCIONADA);

        imageView = (ImageView)findViewById(R.id.miniaturaImg);
        Picasso.get().load(Common.seleccionar_fondo.getUrlImagen()).into(imageView);

        //Añadir a recientes
        anadirARecientes();

        floatingActionButton = (FloatingActionButton)findViewById(R.id.fondoFab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Picasso.get().load(Common.seleccionar_fondo.getUrlImagen()).into(target);

            }
        });

        descargaFab = (FloatingActionButton) findViewById(R.id.DescargaFab);
        descargaFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Comprobar permisos
                if(ActivityCompat.checkSelfPermission(MostrarFondos.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, Common.PERMISSION_REQUEST_CODE);

                }
                else
                {
                    AlertDialog dialog = new SpotsDialog(MostrarFondos.this);
                    dialog.show();
                    dialog.setMessage("Porfavor espere...");

                    String fileName = UUID.randomUUID().toString()+".png";
                    Picasso.get().load(Common.seleccionar_fondo.getUrlImagen())
                            .into(new SaveImageHelper(getBaseContext(),
                                    dialog,
                                    getApplicationContext().getContentResolver(),
                                    fileName,"BestBackgrounds Imagen"));
                }
            }
        });

        //Numero de veces listado
        incrementarNumVisto();

    }

    private void incrementarNumVisto() {
        FirebaseDatabase.getInstance()
                .getReference(Common.STR_FONDO_CATEGORIA)
                .child(Common.seleccionar_fondo_key)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("numVisto")){
                    FondoItem fondoItem = dataSnapshot.getValue(FondoItem.class);
                    long count = fondoItem.getNumVisto()+1;
                    
                    //Actualizar
                    Map<String, Object> actualizarFondo = new HashMap<>();
                    actualizarFondo.put("numVisto", count);

                    FirebaseDatabase.getInstance()
                            .getReference(Common.STR_FONDO_CATEGORIA)
                            .child(Common.seleccionar_fondo_key)
                            .updateChildren(actualizarFondo)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(MostrarFondos.this, "No se ha podido actualizar el numero de veces listado", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
                else //Si el numero de veces listado no esta por defecto en "1"
                {
                    Map<String, Object> actualizarFondo = new HashMap<>();
                    actualizarFondo.put("numVisto", Long.valueOf(1));

                    FirebaseDatabase.getInstance()
                            .getReference(Common.STR_FONDO_CATEGORIA)
                            .child(Common.seleccionar_fondo_key)
                            .updateChildren(actualizarFondo)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(MostrarFondos.this, "No se ha podido establecer el número de veces listado por defecto", Toast.LENGTH_SHORT).show();
                                }
                            });
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void anadirARecientes() {
        Disposable disposable = Observable.create(new ObservableOnSubscribe<Object>() {

            @Override
            public void subscribe(ObservableEmitter<Object> e) {
                Recientes recientes = new Recientes(
                        Common.seleccionar_fondo.getUrlImagen(),
                        Common.seleccionar_fondo.getIdCategoria(),
                        String.valueOf(System.currentTimeMillis()),
                        Common.seleccionar_fondo_key);
                repositorioReciente.insertarRecientes(recientes);
                e.onComplete();
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Consumer<Object>() {

            @Override
            public void accept(Object o) {

            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) {
                Log.e("ERROR", throwable.getMessage());
            }
        }, new Action() {
            @Override
            public void run() {

            }
        });

        compositeDisposable.add(disposable);

    }

    @Override
    protected void onDestroy() {
        Picasso.get().cancelRequest(target);
        compositeDisposable.clear();
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            finish(); //Cerrar la activity cuando se haga click en el Btn de retroceso
        return super.onOptionsItemSelected(item);    }
}
