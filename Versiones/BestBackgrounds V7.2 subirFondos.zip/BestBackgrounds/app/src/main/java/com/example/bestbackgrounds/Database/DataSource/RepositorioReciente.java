package com.example.bestbackgrounds.Database.DataSource;

import com.example.bestbackgrounds.Database.Recientes;

import java.util.List;

import io.reactivex.Flowable;

public class RepositorioReciente implements IRecientesDataSource {

    private IRecientesDataSource mLocalDataSource;
    private static RepositorioReciente instance;

    public RepositorioReciente(IRecientesDataSource mLocalDataSource) {
        this.mLocalDataSource = mLocalDataSource;
    }

    public static RepositorioReciente getInstance(IRecientesDataSource mLocalDataSource) {
        if(instance == null)
            instance = new RepositorioReciente(mLocalDataSource);
        return instance;
    }

    @Override
    public Flowable<List<Recientes>> getAllRecientes() {
        return mLocalDataSource.getAllRecientes();
    }

    @Override
    public void insertarRecientes(Recientes... recientes) {
        mLocalDataSource.insertarRecientes(recientes);
    }

    @Override
    public void actualizarRecientes(Recientes... recientes) {
        mLocalDataSource.actualizarRecientes(recientes);
    }

    @Override
    public void eliminarRecientes(Recientes... recientes) {
        mLocalDataSource.eliminarRecientes(recientes);
    }

    @Override
    public void eliminarTodosRecientes() {
        mLocalDataSource.eliminarTodosRecientes();
    }
}
