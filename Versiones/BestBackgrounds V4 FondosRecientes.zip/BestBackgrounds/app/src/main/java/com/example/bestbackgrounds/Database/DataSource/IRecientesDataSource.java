package com.example.bestbackgrounds.Database.DataSource;

import com.example.bestbackgrounds.Database.Recientes;

import java.util.List;

import io.reactivex.Flowable;

public interface IRecientesDataSource {
    Flowable<List<Recientes>> getAllRecientes();
    void insertarRecientes(Recientes... recientes);
    void actualizarRecientes(Recientes... recientes);
    void eliminarRecientes(Recientes... recientes);
    void eliminarTodosRecientes(Recientes... recientes);

}
