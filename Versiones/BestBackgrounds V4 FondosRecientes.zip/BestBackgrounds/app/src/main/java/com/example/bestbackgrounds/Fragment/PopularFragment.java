package com.example.bestbackgrounds.Fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bestbackgrounds.R;

/**
 * A simple {@link Fragment} subclass.
 */

public class PopularFragment extends Fragment {

    private static PopularFragment INSTANCE = null;

    public PopularFragment() {
        // Required empty public constructor
    }

    public static PopularFragment getInstance(){
        if (INSTANCE == null)
            INSTANCE = new PopularFragment();
        return INSTANCE;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_popular, container, false);
    }

}
