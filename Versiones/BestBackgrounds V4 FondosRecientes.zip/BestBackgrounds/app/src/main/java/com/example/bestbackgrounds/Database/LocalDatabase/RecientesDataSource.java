package com.example.bestbackgrounds.Database.LocalDatabase;

import com.example.bestbackgrounds.Database.DataSource.IRecientesDataSource;
import com.example.bestbackgrounds.Database.Recientes;

import java.util.List;

import io.reactivex.Flowable;

public class RecientesDataSource implements IRecientesDataSource {

    private RecientesDAO recientesDAO;
    private static RecientesDataSource instance;

    public RecientesDataSource(RecientesDAO recientesDAO) {
        this.recientesDAO = recientesDAO;
    }

    public static RecientesDataSource getInstance(RecientesDAO recientesDAO){
        if(instance == null)
            instance = new RecientesDataSource(recientesDAO);
        return instance;
    }

    @Override
    public Flowable<List<Recientes>> getAllRecientes() {
        return recientesDAO.getAllRecientes();
    }

    @Override
    public void insertarRecientes(Recientes... recientes) {
        recientesDAO.insertarRecientes(recientes);
    }

    @Override
    public void actualizarRecientes(Recientes... recientes) {
        recientesDAO.actualizarRecientes(recientes);
    }

    @Override
    public void eliminarRecientes(Recientes... recientes) {
        recientesDAO.eliminarRecientes(recientes);
    }

    @Override
    public void eliminarTodosRecientes(Recientes... recientes) {
        recientesDAO.eliminarTodosRecientes();
    }
}
